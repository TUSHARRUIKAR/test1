package Interview;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Script {

	WebDriver driver;
	
	@BeforeTest
	public void login() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","C:\\EclipseWorkSpace\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://automationpractice.com");
		driver.manage().window().maximize();
		Thread.sleep(5000);
	    
	}
	
	
	@Test(priority=0)
	public void AcccountCreation() throws InterruptedException
	{
		WebElement SignIn = driver.findElement(By.xpath("//a[@class='login']"));  
		SignIn.click();
		Thread.sleep(6000);
		WebElement EmailAddress = driver.findElement(By.xpath("//input[@id='email_create']"));
		EmailAddress.sendKeys("student21@gmail.com");
		WebElement Create_an_Account = driver.findElement(By.xpath("//button[@id='SubmitCreate']"));
		Create_an_Account.click();
		Thread.sleep(5000);
		
		WebElement Title = driver.findElement(By.xpath("//input[@id='id_gender1']"));
		Title.click();
		WebElement FirstName = driver.findElement(By.xpath("//input[@id='customer_firstname']"));
		//FirstName.clear();
		FirstName.sendKeys("RAJIVS");
		WebElement Lastname = driver.findElement(By.xpath("//input[@id='customer_lastname']"));
		//Lastname.clear();
		Lastname.sendKeys("SHUKLAS");
		WebElement Password = driver.findElement(By.xpath("//input[@id='passwd']"));
		Password.sendKeys("Testing");
		
		WebElement Address_FirstName = driver.findElement(By.xpath("//input[@id='firstname']"));
		Address_FirstName.clear();
		Address_FirstName.sendKeys("RAJIVS");
		WebElement Address_Lastname = driver.findElement(By.xpath("//input[@id='lastname']"));
		Address_Lastname.clear();
		Address_Lastname.sendKeys("SHUKLAS");
		
		WebElement Address = driver.findElement(By.xpath("//input[@id='address1']"));
		Address.sendKeys("Navi Mumbai India");
		WebElement City = driver.findElement(By.xpath("//input[@id='city']"));
		City.sendKeys("Mumbai");
		
		WebElement State = driver.findElement(By.xpath("//select[@id='id_state']"));
		Select selection_State = new Select(State);
		selection_State.selectByVisibleText("Texas");
	
		WebElement Zipcode = driver.findElement(By.xpath("//input[@id='postcode']"));
		Zipcode.sendKeys("41021");
			
		WebElement MobilePhone = driver.findElement(By.xpath("//input[@id='phone_mobile']"));
		MobilePhone.sendKeys("9800098000");
		WebElement alias  = driver.findElement(By.xpath("//input[@id='alias']"));
		alias.clear();
		alias.sendKeys("Tushar");
		
		WebElement Register = driver.findElement(By.xpath("//button[@id='submitAccount']"));
		Register.click();
	    Thread.sleep(5000);
		WebElement Logout = driver.findElement(By.xpath("//a[@class='logout']"));
		Logout.click();
	}

		@Test(dependsOnMethods="AcccountCreation")
		public void signin() throws InterruptedException
		{   
			Thread.sleep(5000);
		    WebElement SignIn = driver.findElement(By.xpath("//a[@class='login']"));  
		    SignIn.click();
		    Thread.sleep(5000);
			WebElement EmailAddress_Login = driver.findElement(By.xpath("//input[@id='email']"));
			EmailAddress_Login.sendKeys("student21@gmail.com");
			WebElement Password_Login = driver.findElement(By.xpath("//input[@id='passwd']"));
			Password_Login.sendKeys("Testing");
			WebElement SIGNIN_LOGIN = driver.findElement(By.xpath("//button[@id='SubmitLogin']"));
			SIGNIN_LOGIN.click();
			
		}
	
	@Test(priority=2)
	public void ProductSelection() throws InterruptedException
	{
		Thread.sleep(6000);
		WebElement Woman = driver.findElement(By.xpath("//div[@id='block_top_menu']/ul/li[1]/a"));
		
		Actions act = new Actions(driver);
		act.moveToElement(Woman).click().build().perform();
	
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("scrollBy(0,800)");
		
		Thread.sleep(7000);
    	WebElement QuikView = driver.findElement(By.linkText("Faded Short Sleeve T-shirts"));
	    QuikView.click();

	    WebElement Quantity = driver.findElement(By.xpath("//p[@id='quantity_wanted_p']//input[@id='quantity_wanted']"));
        Quantity.clear();
	    Quantity.sendKeys("2");
	    WebElement AddToCart = driver.findElement(By.xpath("//p[@id='add_to_cart']/button[@name='Submit']"));
        AddToCart.click();

        String parent = driver.getWindowHandle();
        System.out.println(driver.getWindowHandles());
        
        Thread.sleep(9000);
            
	    WebElement ProceedTocheckout = driver.findElement(By.xpath("//a[@class='btn btn-default button button-medium' and @title='Proceed to checkout']"));
	    ProceedTocheckout.click();
	      
	    Thread.sleep(7000);
	    jse.executeScript("scrollBy(0,700)");
		WebElement ProceedTocheckout1 = driver.findElement(By.xpath("//a[@class='button btn btn-default standard-checkout button-medium' and @title='Proceed to checkout']"));
		    
	    try {
			act.moveToElement(ProceedTocheckout1).click().build().perform();
		    } 
	    catch (Exception e) 
	        {
			act.moveToElement(ProceedTocheckout1).click().build().perform();
			}
	    
    
	    jse.executeScript("scrollBy(0,700)");
	    WebElement ProceedAddress = driver.findElement(By.name("processAddress"));
	    act.moveToElement(ProceedAddress).click().build().perform();
		jse.executeScript("scrollBy(0,700)");
	    Thread.sleep(5000);
		WebElement checkbox = driver.findElement(By.id("uniform-cgv"));
	    act.moveToElement(checkbox).click().build().perform();
	    WebElement processCarrier = driver.findElement(By.name("processCarrier"));
		act.moveToElement(processCarrier).click().build().perform();
		jse.executeScript("scrollBy(0,600)");

	    WebElement Total_Price = driver.findElement(By.xpath("//span[@id='total_price']"));
	    String cost = Total_Price.getText();
	   
	    WebElement PaymentBank = driver.findElement(By.xpath("//a[@class='bankwire']"));
	    PaymentBank.click();
	    jse.executeScript("scrollBy(0,600)");
	   
	    WebElement Confirm_order = driver.findElement(By.xpath("//button//span[contains(text(),'I confirm my order')]"));
	    Confirm_order.click();
	    Thread.sleep(5000);
	    
	    WebElement ProfileName = driver.findElement(By.xpath("//a[@title='View my customer account']"));
	    ProfileName.click();
	    Thread.sleep(5000);
	  
	    WebElement Orderhistory = driver.findElement(By.xpath("//a[@title='Orders']"));
	    Orderhistory.click();
	    Thread.sleep(5000);
	    WebElement Orderhistory_cost = driver.findElement(By.xpath("//table[@id='order-list']//tbody/tr/td[3]/span"));
	    String TotalCost = Orderhistory_cost.getText();
	    
	    Assert.assertEquals(cost, TotalCost);
	    System.out.println("DONE");
	    
	    
	    
	}
	
	
}
